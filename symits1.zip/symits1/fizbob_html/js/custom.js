function validate_subs_form() {
    let x = document.getElementById('subs-email').value;
    let alertyes;
    if (isNaN(x)){
        alertyes = "Please Wait...";
    }
    else{
        alertyes = "SUBSCRIBE";
    }
    document.getElementById('sub-btn').innerHTML = alertyes;
}









